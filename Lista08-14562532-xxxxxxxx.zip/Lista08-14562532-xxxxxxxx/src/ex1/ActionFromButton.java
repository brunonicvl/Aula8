package ex1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;

import javax.swing.JLabel;
import javax.swing.JTextField;

public class ActionFromButton implements ActionListener{
	JTextField campoInserção;
	JLabel campoResultado;
	
	
	public ActionFromButton(JTextField campoInserção, JLabel campoResultado) {
		super();
		this.campoInserção = campoInserção;
		this.campoResultado = campoResultado;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		BigDecimal resultado;
		long n;
		try {
			n = Long.parseLong(campoInserção.getText());
			resultado = Calculator.getFatorial(n);
			campoResultado.setText(resultado.toString());
		}
		catch(NegativeNumberException exception) {
			campoResultado.setText(exception.toString());
		}
		catch(NumberFormatException exception) {
			campoResultado.setText(exception.toString());
		}
		
	}
	
}