package ex1;

import java.math.BigDecimal;

public class Calculator {
	public static BigDecimal getFatorial(long n) throws NegativeNumberException {
		BigDecimal x = BigDecimal.ONE;
		
		if(n<0) throw new NegativeNumberException(n);
		
		for(long i=2; i<=n; i++) {
			x = x.multiply(BigDecimal.valueOf(i));
		}
		return x;
		
	}
}
