package ex1.chatgptversion;

import java.math.BigDecimal;

public class CHATGPTFatorialCalculator {
    public static BigDecimal calcularFatorial(int n) throws IllegalArgumentException {
        if (n < 0) {
            throw new IllegalArgumentException("O número não pode ser negativo");
        }

        BigDecimal resultado = BigDecimal.ONE;
        for (int i = 2; i <= n; i++) {
            resultado = resultado.multiply(BigDecimal.valueOf(i));
        }
        return resultado;
    }
}
