package ex1.chatgptversion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;

public class CHATGPTView extends JFrame {
    private JTextField inputField;
    private JButton calcularButton;
    private JLabel resultadoLabel;

    public CHATGPTView() {
        setTitle("Calculadora de Fatorial");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1));

        inputField = new JTextField();
        calcularButton = new JButton("Calcular");
        resultadoLabel = new JLabel();

        panel.add(inputField);
        panel.add(calcularButton);
        panel.add(resultadoLabel);

        calcularButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int numero = Integer.parseInt(inputField.getText());
                    BigDecimal resultado = CHATGPTFatorialCalculator.calcularFatorial(numero);
                    resultadoLabel.setText("O fatorial de " + numero + " é: " + resultado.toString());
                } catch (NumberFormatException ex) {
                    resultadoLabel.setText("Por favor, insira um número válido.");
                } catch (IllegalArgumentException ex) {
                    resultadoLabel.setText(ex.getMessage());
                }
            }
        });

        add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CHATGPTView();
            }
        });
    }
}
