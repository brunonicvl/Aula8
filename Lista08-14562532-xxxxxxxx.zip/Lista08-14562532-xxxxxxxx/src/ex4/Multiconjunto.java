package ex4;

import java.util.*;

public interface Multiconjunto<T>{
	public void add(T element);
	
	public boolean equals(Multiconjunto<T> m);
	
	public void addAll(Multiconjunto<T> m);
	
	public Collection<T> getMultConjunto();
}
