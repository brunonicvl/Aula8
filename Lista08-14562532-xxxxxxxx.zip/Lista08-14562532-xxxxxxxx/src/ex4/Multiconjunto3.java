package ex4;

import java.util.*;

public class Multiconjunto3<T> implements Multiconjunto<T> {
	private LinkedList<T> multConjunto;
	
	public Multiconjunto3(){
		this.multConjunto = new LinkedList<T>();
	}
	
	public Multiconjunto3(Collection<T> multConjunto){
		this.multConjunto = new LinkedList<T>();
		this.multConjunto.addAll(multConjunto);
	}
	
	public Multiconjunto3(Multiconjunto<T> copy) {
		this.multConjunto = new LinkedList<T>();
		this.multConjunto.addAll(copy.getMultConjunto());
	}

	@Override
	public void add(T element) {
		multConjunto.add(element);
	}

	@Override
	public boolean equals(Multiconjunto<T> m) {
		if(m.getClass().equals(Multiconjunto2.class))
			return new HashSet<T>(multConjunto).hashCode() == m.getMultConjunto().hashCode();
		
		return multConjunto.hashCode() == m.getMultConjunto().hashCode();
	}

	@Override
	public void addAll(Multiconjunto<T> m) {
		multConjunto.addAll(m.getMultConjunto());
	}

	@Override
	public Collection<T> getMultConjunto() {
		return (Collection<T>) multConjunto;
	}

	

}
