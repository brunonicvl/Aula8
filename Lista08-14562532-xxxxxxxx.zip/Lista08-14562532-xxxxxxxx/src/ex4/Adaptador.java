package ex4;

import java.util.*;

public interface Adaptador<T> extends  {
	Multiconjunto<T>();

}
