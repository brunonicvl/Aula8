package ex4;

import java.util.*;

public class Multiconjunto1<T> implements Multiconjunto<T> {
	private ArrayList<T> multConjunto;
	
	public Multiconjunto1(){
		this.multConjunto = new ArrayList<T>();
	}
	
	public Multiconjunto1(Collection<T> multConjunto){
		this.multConjunto = new ArrayList<T>();
		this.multConjunto.addAll(multConjunto);
	}
	
	public Multiconjunto1(Multiconjunto<T> copy) {
		this.multConjunto = new ArrayList<T>();
		this.multConjunto.addAll(copy.getMultConjunto());
	}
	
	@Override
	public void add(T element) {
		multConjunto.add(element);
	}
	
	@Override
	public boolean equals(Multiconjunto<T> m) {
		if(m.getClass().equals(Multiconjunto2.class))
			return new HashSet<T>(multConjunto).hashCode() == m.getMultConjunto().hashCode();
		
		return multConjunto.hashCode() == m.getMultConjunto().hashCode();
	}
	
	@Override
	public void addAll(Multiconjunto<T> m) {
		multConjunto.addAll(m.getMultConjunto());
	}

	@Override
	public Collection<T> getMultConjunto() {
		return (Collection<T>) multConjunto;
	}
}
