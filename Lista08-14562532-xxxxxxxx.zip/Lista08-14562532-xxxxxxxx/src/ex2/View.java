package ex2;

import java.awt.*;
import javax.swing.*;

public class View implements Runnable {
    private JFrame f;
    public View()  {
        // Create the window
        f = new JFrame("Calcule um fatorial!");
        // Sets the behavior for when the window is closed
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        // Add a layout manager so that the button is not placed on top of the label
        f.setLayout(new GridLayout(2,2));
        // Add a label and a button
        JTextField campoInserção = new JTextField();
        JButton calcularButton = new JButton("Calcular");
        JLabel campoResultado = new JLabel();
        
        //REFATORAR: TIRAR A DEFINIÇÃO DA CLASSE DE AÍ DENTRO LOL
        calcularButton.addActionListener(new ActionFromButton(campoInserção, campoResultado));
        
        f.add(new JLabel("Insira um número:"));
        f.add(campoInserção);
        f.add(calcularButton);
        f.add(campoResultado);
    }

    @Override
    public void run() {
        // Arrange the components inside the window
        f.pack();
        // By default, the window is not visible. Make it visible.
        f.setVisible(true);
    }
 
    public static void main(String[] args) {
        // Schedules the application to be run at the correct time in the event queue.
        SwingUtilities.invokeLater(new View());
    }
}
