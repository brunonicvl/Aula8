package ex2;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

public class TesteEx1 {
	
}

/* O teste para determinação do funcionamento adequado do programa,
 * neste contexto, se dá por um teste de aceitação, que difere do teste de unidade
 * à medida que não será aplicado sobre trechos do programa, e sim em relação ao
 * funcionamento do programa em nível do usuário (com comportamento padronizado automatizável)
 */

