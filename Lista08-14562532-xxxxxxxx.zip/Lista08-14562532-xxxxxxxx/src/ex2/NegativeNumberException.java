package ex2;

public class NegativeNumberException extends Exception{
	private long invalidN;
	private static final long serialVersionUID = 1L;
	
	public NegativeNumberException(long n) {
		invalidN = n;
	}
	
	public String toString() {
		return "Número (" + invalidN + ") negativo não é permitido";
	}
	
}
