package ex3;

import java.util.*;

public class Multiconjunto4<T> implements Multiconjunto<T> {
	private Stack<T> multConjunto;
	
	public Multiconjunto4(){
		this.multConjunto = new Stack<T>();
	}
	
	public Multiconjunto4(Collection<T> multConjunto){
		this.multConjunto = new Stack<T>();
		this.multConjunto.addAll(multConjunto);
	}
	
	public Multiconjunto4(Multiconjunto<T> copy) {
		this.multConjunto = new Stack<T>();
		this.multConjunto.addAll(copy.getMultConjunto());
	}

	@Override
	public void add(T element) {
		multConjunto.add(element);
	}

	@Override
	public boolean equals(Multiconjunto<T> m) {
		if(m.getClass().equals(Multiconjunto2.class))
			return new HashSet<T>(multConjunto).hashCode() == m.getMultConjunto().hashCode();
		
		return multConjunto.hashCode() == m.getMultConjunto().hashCode();
	}

	@Override
	public void addAll(Multiconjunto<T> m) {
		multConjunto.addAll(m.getMultConjunto());
	}

	@Override
	public Collection<T> getMultConjunto() {
		return (Collection<T>) multConjunto;
	}

	

}
