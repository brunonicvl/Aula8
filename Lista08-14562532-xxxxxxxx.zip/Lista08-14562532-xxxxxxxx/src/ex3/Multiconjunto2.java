package ex3;

import java.util.*;

public class Multiconjunto2<T> implements Multiconjunto<T> {
	private Set<T> multConjunto;
	
	public Multiconjunto2(){
		this.multConjunto = new HashSet<T>();
	}
	
	public Multiconjunto2(Collection<T> multConjunto){
		this.multConjunto = new HashSet<T>(multConjunto);
	}
	
	public Multiconjunto2(Multiconjunto<T> copy) {
		this.multConjunto = new HashSet<T>(copy.getMultConjunto());
	}

	@Override
	public void add(T element) {
		multConjunto.add(element);
	}

	@Override
	public boolean equals(Multiconjunto<T> m) {
		return multConjunto.hashCode() == new HashSet<T>(m.getMultConjunto()).hashCode();
	}

	@Override
	public void addAll(Multiconjunto<T> m) {
		multConjunto.addAll(m.getMultConjunto());
	}

	@Override
	public Collection<T> getMultConjunto() {
		return (Collection<T>) multConjunto;
	}

	

}
