package ex3;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

public class TestClass {
	Multiconjunto1<Integer> mI1;
	Multiconjunto2<Integer> mI2;
	Multiconjunto3<Integer> mI3;
	Multiconjunto4<Integer> mI4;
	
	Multiconjunto1<String> mS1;
	Multiconjunto2<String> mS2;
	Multiconjunto3<String> mS3;
	Multiconjunto4<String> mS4;
	
	@Test
	public void addAllParaDefinirClasse1() {
		//1 por 1
		mI1 = new Multiconjunto1<Integer>();
		mI1.add(8);
		mI1.add(7);
		mI1.add(6);
		mI1.add(5);
		mI1.add(4);
		
		Multiconjunto1<Integer> m1 = new Multiconjunto1<Integer>(mI1);
		
		Integer[] a = new Integer[5], b = {8, 7, 6, 5, 4};
		
		m1.getMultConjunto().toArray(a);
		
		int i = 0;
		while (i<5)
			assertTrue(b[i] == a[i++]);
		
		//1 por 2
		mI2 = new Multiconjunto2<Integer>();
		mI2.add(5);
		mI2.add(4);
		mI2.add(3);
		mI2.add(2);
		mI2.add(1);
		
		m1 = new Multiconjunto1<Integer>(mI2);
		
		Integer[] c = new Integer[5], d = {1, 2, 3, 4, 5};
		
		m1.getMultConjunto().toArray(c);
		
		i = 0;
		while (i<5) 
			assertEquals(d[i], c[i++]);
		
		//1 por 3
		mI3 = new Multiconjunto3<Integer>();
		mI3.add(0);
		mI3.add(-1);
		mI3.add(-2);
		mI3.add(-3);
		mI3.add(-4);
		
		m1 = new Multiconjunto1<Integer>(mI3);
			
		Integer[] e = new Integer[5], f = {0, -1, -2, -3, -4};
			
		m1.getMultConjunto().toArray(e);
			
		i = 0;
		while (i<5)
			assertTrue(e[i] == f[i++]);
			
		//1 por 4
		mI4 = new Multiconjunto4<Integer>();
		mI4.add(1);
		mI4.add(2);
		mI4.add(3);
		mI4.add(4);
		mI4.add(5);
		
		m1 = new Multiconjunto1<Integer>(mI4);
		
		Integer[] g = new Integer[5], h = {1, 2, 3, 4, 5};
		
		m1.getMultConjunto().toArray(g);
		
		i = 0;
		while (i<5) 
			assertEquals(g[i], h[i++]);
	}
	
	@Test
	public void addAllParaDefinirClasse2() {
		//2 por 1
		mI1 = new Multiconjunto1<Integer>();
		mI1.add(8);
		mI1.add(7);
		mI1.add(6);
		mI1.add(5);
		mI1.add(4);
		
		Multiconjunto2<Integer> m2 = new Multiconjunto2<Integer>(mI1);
		
		Integer[] a = new Integer[5], b = {4, 5, 6, 7, 8};
		
		m2.getMultConjunto().toArray(a);
		
		int i = 0;
		while (i<5)
			assertTrue(b[i] == a[i++]);
		
		//2 por 2
		mI2 = new Multiconjunto2<Integer>();
		mI2.add(5);
		mI2.add(4);
		mI2.add(3);
		mI2.add(2);
		mI2.add(1);
		
		m2 = new Multiconjunto2<Integer>(mI2);
		
		Integer[] c = new Integer[5], d = {1, 2, 3, 4, 5};
		
		m2.getMultConjunto().toArray(c);
		
		i = 0;
		while (i<5) 
			assertEquals(d[i], c[i++]);
		
		//2 por 3
		mI3 = new Multiconjunto3<Integer>();
		mI3.add(0);
		mI3.add(-1);
		mI3.add(-2);
		mI3.add(-3);
		mI3.add(-4);
		
		m2 = new Multiconjunto2<Integer>(mI3);
			
		Integer[] e = new Integer[5], f = {0, -1, -2, -3, -4};
			
		m2.getMultConjunto().toArray(e);
			
		i = 0;
		while (i<5)
			assertTrue(e[i] == f[i++]);
			
		//2 por 4
		mI4 = new Multiconjunto4<Integer>();
		mI4.add(1);
		mI4.add(2);
		mI4.add(3);
		mI4.add(4);
		mI4.add(5);
		
		m2 = new Multiconjunto2<Integer>(mI4);
		
		Integer[] g = new Integer[5], h = {1, 2, 3, 4, 5};
		
		m2.getMultConjunto().toArray(g);
		
		i = 0;
		while (i<5)
			assertEquals(g[i], h[i++]);
	}
	
	@Test
	public void addAllParaDefinirClasse3() {
		//3 por 1
		mI1 = new Multiconjunto1<Integer>();
		mI1.add(8);
		mI1.add(7);
		mI1.add(6);
		mI1.add(5);
		mI1.add(4);
		
		Multiconjunto3<Integer> m3 = new Multiconjunto3<Integer>(mI1);
		
		Integer[] a = new Integer[5], b = {8, 7, 6, 5, 4};
		
		m3.getMultConjunto().toArray(a);
		
		int i = 0;
		while (i<5)
			assertTrue(b[i] == a[i++]);
		
		//3 por 2
		mI2 = new Multiconjunto2<Integer>();
		mI2.add(5);
		mI2.add(4);
		mI2.add(3);
		mI2.add(2);
		mI2.add(1);
		
		m3 = new Multiconjunto3<Integer>(mI2);
		
		Integer[] c = new Integer[5], d = {1, 2, 3, 4, 5};
		
		m3.getMultConjunto().toArray(c);
		
		i = 0;
		while (i<5) 
			assertEquals(d[i], c[i++]);
		
		//3 por 3
		mI3 = new Multiconjunto3<Integer>();
		mI3.add(0);
		mI3.add(-1);
		mI3.add(-2);
		mI3.add(-3);
		mI3.add(-4);
		
		m3 = new Multiconjunto3<Integer>(mI3);
			
		Integer[] e = new Integer[5], f = {0, -1, -2, -3, -4};
			
		m3.getMultConjunto().toArray(e);
			
		i = 0;
		while (i<5)
			assertTrue(e[i] == f[i++]);
			
		//3 por 4
		mI4 = new Multiconjunto4<Integer>();
		mI4.add(1);
		mI4.add(2);
		mI4.add(3);
		mI4.add(4);
		mI4.add(5);
		
		m3 = new Multiconjunto3<Integer>(mI4);
		
		Integer[] g = new Integer[5], h = {1, 2, 3, 4, 5};
		
		m3.getMultConjunto().toArray(g);
		
		i = 0;
		while (i<5) 
			assertEquals(g[i], h[i++]);
	}
	
	@Test
	public void addAllParaDefinirClasse4() {
		//4 por 1
		mI1 = new Multiconjunto1<Integer>();
		mI1.add(8);
		mI1.add(7);
		mI1.add(6);
		mI1.add(5);
		mI1.add(4);
		
		Multiconjunto4<Integer> m4 = new Multiconjunto4<Integer>(mI1);
		
		Integer[] a = new Integer[5], b = {8, 7, 6, 5, 4};
		
		m4.getMultConjunto().toArray(a);
		
		int i = 0;
		while (i<5)
			assertTrue(b[i] == a[i++]);
		
		//4 por 2
		mI2 = new Multiconjunto2<Integer>();
		mI2.add(5);
		mI2.add(4);
		mI2.add(3);
		mI2.add(2);
		mI2.add(1);
		
		m4 = new Multiconjunto4<Integer>(mI2);
		
		Integer[] c = new Integer[5], d = {1, 2, 3, 4, 5};
		
		m4.getMultConjunto().toArray(c);
		
		i = 0;
		while (i<5) 
			assertEquals(d[i], c[i++]);
		
		//4 por 3
		mI3 = new Multiconjunto3<Integer>();
		mI3.add(0);
		mI3.add(-1);
		mI3.add(-2);
		mI3.add(-3);
		mI3.add(-4);
		
		m4 = new Multiconjunto4<Integer>(mI3);
			
		Integer[] e = new Integer[5], f = {0, -1, -2, -3, -4};
			
		m4.getMultConjunto().toArray(e);
			
		i = 0;
		while (i<5)
			assertTrue(e[i] == f[i++]);
			
		//4 por 4
		mI4 = new Multiconjunto4<Integer>();
		mI4.add(1);
		mI4.add(2);
		mI4.add(3);
		mI4.add(4);
		mI4.add(5);
		
		m4 = new Multiconjunto4<Integer>(mI4);
		
		Integer[] g = new Integer[5], h = {1, 2, 3, 4, 5};
		
		m4.getMultConjunto().toArray(g);
		
		i = 0;
		while (i<5) 
			assertEquals(g[i], h[i++]);
	}
	
	
	@Test
	public void concatenaçãoTodosDeUmaVez() {
		mS1 = new Multiconjunto1<String>();
		mS1.add("Isso");
		
		mS2 = new Multiconjunto2<String>();
		mS2.add("foi");
		mS2.add("inteiramente");
		
		mS3 = new Multiconjunto3<String>();
		mS3.add("concatenado,");
		mS3.add("ou seja,");
		
		mS4 = new Multiconjunto4<String>();
		mS4.add("funcionou");
		mS4.add("direitinho!");
		
		mS1.addAll(mS2);
		mS1.addAll(mS3);
		mS1.addAll(mS4);
		
		String[] a = new String[7];
		String finalMessage = "";
		
		mS1.getMultConjunto().toArray(a);
		for(int i=0; i<a.length; i++) {
			finalMessage += a[i];
			if(i+1!=a.length) finalMessage += " ";
		}
		
		assertEquals("Isso foi inteiramente concatenado, ou seja, funcionou direitinho!", finalMessage);
	}
	
	@Test
	public void testarEquals() {
		mI1 = new Multiconjunto1<Integer>();
		mI1.add(3);
		mI1.add(4);
		mI1.add(5);
		
		mI2 = new Multiconjunto2<Integer>();
		mI2.add(3);
		mI2.add(4);
		mI2.add(5);
		
		mI3 = new Multiconjunto3<Integer>();
		mI3.add(3);
		mI3.add(4);
		mI3.add(5);
		
		mI4 = new Multiconjunto4<Integer>();
		mI4.add(3);
		mI4.add(4);
		mI4.add(5);
		
		assertTrue(mI1.equals(mI2));
		assertTrue(mI2.equals(mI3));
		assertTrue(mI3.equals(mI4));
		assertTrue(mI4.equals(mI1));
		
		mI2.add(6);
		mI3.add(7);
		mI4.add(8);
		
		assertFalse(mI1.equals(mI2));
		assertFalse(mI2.equals(mI3));
		assertFalse(mI3.equals(mI4));
		assertFalse(mI4.equals(mI1));
	}
}
